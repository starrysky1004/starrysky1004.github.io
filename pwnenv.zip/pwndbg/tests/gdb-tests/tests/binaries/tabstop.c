#include <stdio.h>

int main() {
	// test mix indent
        do {
		puts("tab line");
        } while (0);
        return 0;
}

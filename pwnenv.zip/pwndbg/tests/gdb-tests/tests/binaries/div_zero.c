int main() {
  return 1 / 0;
}

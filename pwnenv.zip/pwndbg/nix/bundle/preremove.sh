#!/bin/sh

rm -rf /usr/lib/pwndbg/cache || true

## Command: regs ##
```
usage: regs [-h] [regs [regs ...]]
```
Print out all registers and enhance the information.  

| Positional Argument | Info |
|---------------------|------|
| regs | Registers to be shown |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



## Command: fsbase ##
```
usage: fsbase [-h]
```
Prints out the FS base address. See also $fsbase.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



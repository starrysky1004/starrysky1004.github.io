## Command: argv ##
```
usage: argv [-h] [i]
```
Prints out the contents of argv.  

| Positional Argument | Info |
|---------------------|------|
| i | Index of the argument to print out. |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



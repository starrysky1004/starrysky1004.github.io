## Command: envp ##
```
usage: envp [-h] [name]
```
Prints out the contents of the environment.  

| Positional Argument | Info |
|---------------------|------|
| name | Name of the environment variable to see. |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



## Command: procinfo ##
```
usage: procinfo [-h]
```
Display information about the running process.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



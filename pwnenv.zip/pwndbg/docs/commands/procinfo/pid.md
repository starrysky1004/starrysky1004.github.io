## Command: pid ##
```
usage: pid [-h]
```
Gets the pid.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



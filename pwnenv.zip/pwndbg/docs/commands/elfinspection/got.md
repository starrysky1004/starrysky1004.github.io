## Command: got ##
```
usage: got [-h] [name_filter]
```
Show the state of the Global Offset Table  

| Positional Argument | Info |
|---------------------|------|
| name_filter | Filter results by passed name. (default: ) |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



## Command: checksec ##
```
usage: checksec [-h]
```
Prints out the binary security settings using `checksec`.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



## Command: auxv ##
```
usage: auxv [-h]
```
Print information from the Auxiliary ELF Vector.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



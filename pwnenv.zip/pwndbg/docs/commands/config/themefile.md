## Command: themefile ##
```
usage: themefile [-h] [--show-all]
```
Generates a configuration file for the current Pwndbg theme options  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |
| --show-all | Force displaying of all theme options. (default: False) |



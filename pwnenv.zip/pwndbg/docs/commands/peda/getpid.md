## Command: getpid ##
```
usage: getpid [-h]
```
Get the pid.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



## Command: libs ##
```
usage: libs [-h]
```
GDBINIT compatibility alias for 'libs' command.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



## Command: sstart ##
```
usage: sstart [-h]
```
GDBINIT compatibility alias for 'tbreak __libc_start_main; run' command.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



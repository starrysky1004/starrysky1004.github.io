## Command: init ##
```
usage: init [-h]
```
GDBINIT compatibility alias for 'start' command.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



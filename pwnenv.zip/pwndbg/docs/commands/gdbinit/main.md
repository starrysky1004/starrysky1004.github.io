## Command: main ##
```
usage: main [-h]
```
GDBINIT compatibility alias for 'main' command.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



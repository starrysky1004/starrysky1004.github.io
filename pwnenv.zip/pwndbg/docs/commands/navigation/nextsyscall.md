## Command: nextsyscall ##
```
usage: nextsyscall [-h]
```
Breaks at the next syscall not taking branches.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



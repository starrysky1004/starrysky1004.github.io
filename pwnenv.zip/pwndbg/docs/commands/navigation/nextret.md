## Command: nextret ##
```
usage: nextret [-h]
```
Breaks at next return-like instruction  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



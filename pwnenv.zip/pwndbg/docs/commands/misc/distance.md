## Command: distance ##
```
usage: distance [-h] a b
```
Print the distance between the two arguments.  

| Positional Argument | Info |
|---------------------|------|
| a | The first address. |
| b | The second address. |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



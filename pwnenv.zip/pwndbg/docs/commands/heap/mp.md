## Command: mp ##
```
usage: mp [-h]
```
Prints out the mp_ structure from glibc.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



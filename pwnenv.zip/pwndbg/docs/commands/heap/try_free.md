## Command: try_free ##
```
usage: try_free [-h] [addr]
```
Check what would happen if free was called with given address

| Positional Argument | Info |
|---------------------|------|
| addr | Address passed to free |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |

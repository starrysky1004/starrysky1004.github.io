## Command: arena ##
```
usage: arena [-h] [addr]
```
Prints out the main arena or the arena at the specified by address.  

| Positional Argument | Info |
|---------------------|------|
| addr | The address of the arena. |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



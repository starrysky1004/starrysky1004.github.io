## Command: heap ##
```
usage: heap [-h] [addr]
```
Prints out chunks starting from the address specified by `addr`.  

| Positional Argument | Info |
|---------------------|------|
| addr | The address of the heap. |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



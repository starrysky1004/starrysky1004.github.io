## Command: tcache ##
```
usage: tcache [-h] [addr]
```
Print malloc thread cache info.  

| Positional Argument | Info |
|---------------------|------|
| addr | The address of the tcache. |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



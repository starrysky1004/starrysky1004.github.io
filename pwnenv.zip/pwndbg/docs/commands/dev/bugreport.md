## Command: bugreport ##
```
usage: bugreport [-h] [--run-browser]
```
Generate bugreport  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |
| --run-browser | Open browser on github/issues/new (default: False) |



## Command: version ##
```
usage: version [-h]
```
Displays gdb, python and pwndbg versions.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



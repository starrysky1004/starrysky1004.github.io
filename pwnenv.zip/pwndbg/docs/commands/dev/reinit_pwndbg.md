## Command: reinit_pwndbg ##
```
usage: reinit_pwndbg [-h]
```
Makes pwndbg reinitialize all state.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



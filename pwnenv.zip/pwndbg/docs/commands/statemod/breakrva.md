## Command: breakrva ##
```
usage: breakrva [-h] [offset] [module]
```
Break at RVA from PIE base.  

| Positional Argument | Info |
|---------------------|------|
| offset | Offset to add. (default: 0) |
| module | Module to choose as base. Defaults to the target executable. (default: ) |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



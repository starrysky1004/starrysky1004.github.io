## Command: j ##
```
usage: j [-h]
```
Synchronize IDA's cursor with GDB  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



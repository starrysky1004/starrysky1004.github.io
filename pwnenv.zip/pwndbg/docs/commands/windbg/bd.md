## Command: bd ##
```
usage: bd [-h] [which]
```
Disable the breakpoint with the specified index.  

| Positional Argument | Info |
|---------------------|------|
| which | Index of the breakpoint to disable. (default: *) |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



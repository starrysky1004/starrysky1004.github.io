## Command: go ##
```
usage: go [-h]
```
Windbg compatibility alias for 'continue' command.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



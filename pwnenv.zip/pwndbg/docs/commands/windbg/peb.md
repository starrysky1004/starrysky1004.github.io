## Command: peb ##
```
usage: peb [-h]
```
Not be windows.  

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



## Command: ew ##
```
usage: ew [-h] address [data [data ...]]
```
Write hex words at the specified address.  

| Positional Argument | Info |
|---------------------|------|
| address | The address to write to. |
| data | The words to write. |

| Optional Argument | Info |
|---------------------|------|
| --help | show this help message and exit |



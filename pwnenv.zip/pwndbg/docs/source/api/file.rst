:mod:`pwndbg.gdblib.file` --- pwndbg.gdblib.file
=============================================

.. automodule:: pwndbg.gdblib.file
    :members:

:mod:`pwndbg.gdblib.prompt` --- pwndbg.gdblib.prompt
=============================================

.. automodule:: pwndbg.gdblib.prompt
    :members:

:mod:`pwndbg.gdblib.config` --- pwndbg.gdblib.config
=============================================

.. automodule:: pwndbg.gdblib.config
    :members:

:mod:`pwndbg.search` --- pwndbg.search
=============================================

.. automodule:: pwndbg.search
    :members:

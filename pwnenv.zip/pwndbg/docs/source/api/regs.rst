:mod:`pwndbg.gdblib.regs` --- pwndbg.gdblib.regs
=============================================

.. automodule:: pwndbg.gdblib.regs
    :members:

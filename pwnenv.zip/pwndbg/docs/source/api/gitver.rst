:mod:`pwndbg.gitver` --- pwndbg.gitver
=============================================

.. automodule:: pwndbg.gitver
    :members:

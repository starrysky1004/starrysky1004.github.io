:mod:`pwndbg.gdblib.elftypes` --- pwndbg.gdblib.elftypes
=============================================

.. automodule:: pwndbg.gdblib.elftypes
    :members:

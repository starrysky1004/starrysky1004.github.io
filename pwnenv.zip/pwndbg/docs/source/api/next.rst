:mod:`pwndbg.gdblib.next` --- pwndbg.gdblib.next
=============================================

.. automodule:: pwndbg.gdblib.next
    :members:

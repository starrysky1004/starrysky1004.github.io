:mod:`pwndbg.gdblib.elf` --- pwndbg.gdblib.elf
=============================================

.. automodule:: pwndbg.gdblib.elf
    :members:

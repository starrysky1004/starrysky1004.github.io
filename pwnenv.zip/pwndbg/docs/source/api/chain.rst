:mod:`pwndbg.chain` --- pwndbg.chain
=============================================

.. automodule:: pwndbg.chain
    :members:
